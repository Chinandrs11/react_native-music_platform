import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, ScrollView } from 'react-native';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

export default function PlaylistsScreen({ navigation }) {
  const { API_URL, logout, user } = useAuth();
  const [playlists, setPlaylists] = useState([]);
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [songIds, setSongIds] = useState([]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [plRes, songsRes] = await Promise.all([
        axios.get(`${API_URL}/playlists`),
        axios.get(`${API_URL}/songs`),
      ]);
      setPlaylists(plRes.data);
      setSongs(songsRes.data);
    } catch (err) {
      console.log('Error al cargar playlists', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const toggleSong = (id) => {
    setSongIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const handleSubmit = async () => {
    try {
      const payload = { name, description, songIds };
      if (editingId) {
        const { data } = await axios.put(`${API_URL}/playlists/${editingId}`, payload);
        setPlaylists((prev) => prev.map((p) => (p._id === editingId ? data : p)));
      } else {
        const { data } = await axios.post(`${API_URL}/playlists`, payload);
        setPlaylists((prev) => [...prev, data]);
      }
      setName('');
      setDescription('');
      setSongIds([]);
      setEditingId(null);
    } catch (err) {
      console.log('Error al guardar playlist', err);
    }
  };

  const handleEdit = (pl) => {
    setEditingId(pl._id);
    setName(pl.name);
    setDescription(pl.description || '');
    const ids = pl.songs ? pl.songs.map((s) => s._id || s) : [];
    setSongIds(ids);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/playlists/${id}`);
      setPlaylists((prev) => prev.filter((p) => p._id !== id));
    } catch (err) {
      console.log('Error al eliminar playlist', err);
    }
  };

  const renderPlaylist = ({ item }) => (
    <View style={styles.playlistItem}>
      <View style={{ flex: 1 }}>
        <Text style={styles.playlistName}>{item.name}</Text>
        {item.description ? (
          <Text style={styles.playlistDescription}>{item.description}</Text>
        ) : null}
        <Text style={styles.songCount}>
          {item.songs?.length || 0} canciones
        </Text>
      </View>
      <View style={styles.playlistActions}>
        <TouchableOpacity style={styles.secondaryButton} onPress={() => handleEdit(item)}>
          <Text style={styles.secondaryButtonText}>Editar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.dangerButton} onPress={() => handleDelete(item._id)}>
          <Text style={styles.dangerButtonText}>Borrar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  const isSongSelected = (id) => songIds.includes(id);

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <View>
          <Text style={styles.title}>Playlists</Text>
          <Text style={styles.subtitle}>Hola, {user?.name || user?.email}</Text>
        </View>
        <TouchableOpacity style={styles.smallButton} onPress={() => navigation.navigate('Songs')}>
          <Text style={styles.smallButtonText}>Canciones</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.smallOutlineButton} onPress={logout}>
          <Text style={styles.smallOutlineButtonText}>Salir</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.formCard}>
        <Text style={styles.formTitle}>
          {editingId ? 'Editar playlist' : 'Nueva playlist'}
        </Text>

        <Text style={styles.label}>Nombre</Text>
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
          placeholder="Nombre de la playlist"
          placeholderTextColor="#6b7280"
        />

        <Text style={styles.label}>Descripción</Text>
        <TextInput
          style={styles.input}
          value={description}
          onChangeText={setDescription}
          placeholder="Ej: para estudiar, gimnasio, etc."
          placeholderTextColor="#6b7280"
        />

        <Text style={styles.label}>Canciones</Text>
        <ScrollView style={styles.songsSelector}>
          {songs.map((song) => (
            <TouchableOpacity
              key={song._id}
              style={[
                styles.songChip,
                isSongSelected(song._id) && styles.songChipSelected,
              ]}
              onPress={() => toggleSong(song._id)}
            >
              <Text
                style={[
                  styles.songChipText,
                  isSongSelected(song._id) && styles.songChipTextSelected,
                ]}
              >
                {song.title} – {song.artist}
              </Text>
            </TouchableOpacity>
          ))}
          {songs.length === 0 && (
            <Text style={styles.emptySongsText}>
              No hay canciones. Crea canciones primero en la pantalla de Canciones.
            </Text>
          )}
        </ScrollView>

        <TouchableOpacity style={styles.button} onPress={handleSubmit}>
          <Text style={styles.buttonText}>
            {editingId ? 'Actualizar playlist' : 'Crear playlist'}
          </Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.sectionTitle}>
        {loading ? 'Cargando playlists...' : 'Lista de playlists'}
      </Text>

      <FlatList
        data={playlists}
        keyExtractor={(item) => item._id}
        renderItem={renderPlaylist}
        contentContainerStyle={{ paddingBottom: 32 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
    padding: 16,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    color: '#f9fafb',
  },
  subtitle: {
    fontSize: 12,
    color: '#9ca3af',
  },
  formCard: {
    backgroundColor: '#020617',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#1f2937',
  },
  formTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#e5e7eb',
    marginBottom: 8,
  },
  label: {
    fontSize: 12,
    color: '#9ca3af',
    marginBottom: 4,
  },
  input: {
    backgroundColor: '#020617',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#4b5563',
    color: '#e5e7eb',
    marginBottom: 10,
  },
  songsSelector: {
    maxHeight: 150,
    marginBottom: 10,
  },
  songChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#4b5563',
    marginBottom: 6,
  },
  songChipSelected: {
    backgroundColor: '#22c55e33',
    borderColor: '#22c55e',
  },
  songChipText: {
    color: '#e5e7eb',
    fontSize: 12,
  },
  songChipTextSelected: {
    color: '#bbf7d0',
  },
  button: {
    backgroundColor: '#22c55e',
    borderRadius: 999,
    paddingVertical: 10,
    alignItems: 'center',
    marginTop: 4,
  },
  buttonText: {
    color: '#020617',
    fontWeight: '700',
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#e5e7eb',
    marginBottom: 8,
  },
  playlistItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#020617',
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#1f2937',
  },
  playlistName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#f9fafb',
  },
  playlistDescription: {
    fontSize: 12,
    color: '#9ca3af',
  },
  songCount: {
    fontSize: 11,
    color: '#6b7280',
    marginTop: 2,
  },
  playlistActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  secondaryButton: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: '#111827',
    marginRight: 6,
  },
  secondaryButtonText: {
    color: '#e5e7eb',
    fontSize: 12,
  },
  dangerButton: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: '#b91c1c',
  },
  dangerButtonText: {
    color: '#f9fafb',
    fontSize: 12,
  },
  smallButton: {
    backgroundColor: '#22c55e',
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  smallButtonText: {
    color: '#020617',
    fontSize: 12,
    fontWeight: '600',
  },
  smallOutlineButton: {
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: '#4b5563',
  },
  smallOutlineButtonText: {
    color: '#e5e7eb',
    fontSize: 12,
    fontWeight: '600',
  },
  emptySongsText: {
    color: '#9ca3af',
    fontSize: 12,
  },
});
