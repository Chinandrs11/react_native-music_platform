import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

export default function SongsScreen({ navigation }) {
  const { API_URL, logout, user } = useAuth();
  const [songs, setSongs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState(null);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [fileUrl, setFileUrl] = useState('');

  const fetchSongs = async () => {
    try {
      setLoading(true);
      const { data } = await axios.get(`${API_URL}/songs`);
      setSongs(data);
    } catch (err) {
      console.log('Error al cargar canciones', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSongs();
  }, []);

  const handleSubmit = async () => {
    try {
      const payload = { title, artist, fileUrl };
      if (editingId) {
        const { data } = await axios.put(`${API_URL}/songs/${editingId}`, payload);
        setSongs(prev => prev.map(s => (s._id === editingId ? data : s)));
      } else {
        const { data } = await axios.post(`${API_URL}/songs`, payload);
        setSongs(prev => [...prev, data]);
      }
      setTitle('');
      setArtist('');
      setFileUrl('');
      setEditingId(null);
    } catch (err) {
      console.log('Error al guardar canción', err);
    }
  };

  const handleEdit = (song) => {
    setEditingId(song._id);
    setTitle(song.title);
    setArtist(song.artist);
    setFileUrl(song.fileUrl);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/songs/${id}`);
      setSongs(prev => prev.filter(s => s._id !== id));
    } catch (err) {
      console.log('Error al eliminar canción', err);
    }
  };

  const renderItem = ({ item }) => (
    <View style={styles.songItem}>
      <View style={{ flex: 1 }}>
        <Text style={styles.songTitle}>{item.title}</Text>
        <Text style={styles.songArtist}>{item.artist}</Text>
      </View>
      <View style={styles.songActions}>
        <TouchableOpacity style={styles.secondaryButton} onPress={() => handleEdit(item)}>
          <Text style={styles.secondaryButtonText}>Editar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.dangerButton} onPress={() => handleDelete(item._id)}>
          <Text style={styles.dangerButtonText}>Borrar</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <View>
          <Text style={styles.title}>Canciones</Text>
          <Text style={styles.subtitle}>Hola, {user?.name || user?.email}</Text>
        </View>
        <TouchableOpacity style={styles.smallButton} onPress={() => navigation.navigate('Playlists')}>
          <Text style={styles.smallButtonText}>Playlists</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.smallOutlineButton} onPress={logout}>
          <Text style={styles.smallOutlineButtonText}>Salir</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.formCard}>
        <Text style={styles.formTitle}>{editingId ? 'Editar canción' : 'Nueva canción'}</Text>

        <Text style={styles.label}>Título</Text>
        <TextInput
          style={styles.input}
          value={title}
          onChangeText={setTitle}
          placeholder="Nombre de la canción"
          placeholderTextColor="#6b7280"
        />

        <Text style={styles.label}>Artista</Text>
        <TextInput
          style={styles.input}
          value={artist}
          onChangeText={setArtist}
          placeholder="Nombre del artista"
          placeholderTextColor="#6b7280"
        />

        <Text style={styles.label}>URL del MP3</Text>
        <TextInput
          style={styles.input}
          value={fileUrl}
          onChangeText={setFileUrl}
          placeholder="https://.../archivo.mp3"
          placeholderTextColor="#6b7280"
        />

        <TouchableOpacity style={styles.button} onPress={handleSubmit}>
          <Text style={styles.buttonText}>
            {editingId ? 'Actualizar canción' : 'Agregar canción'}
          </Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.sectionTitle}>
        {loading ? 'Cargando canciones...' : 'Lista de canciones'}
      </Text>

      <FlatList
        data={songs}
        keyExtractor={item => item._id}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 32 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f172a',
    padding: 16,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  title: {
    fontSize: 22,
    fontWeight: '700',
    color: '#f9fafb',
  },
  subtitle: {
    fontSize: 12,
    color: '#9ca3af',
  },
  formCard: {
    backgroundColor: '#020617',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#1f2937',
  },
  formTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#e5e7eb',
    marginBottom: 8,
  },
  label: {
    fontSize: 12,
    color: '#9ca3af',
    marginBottom: 4,
  },
  input: {
    backgroundColor: '#020617',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: '#4b5563',
    color: '#e5e7eb',
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#22c55e',
    borderRadius: 999,
    paddingVertical: 10,
    alignItems: 'center',
    marginTop: 4,
  },
  buttonText: {
    color: '#020617',
    fontWeight: '700',
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#e5e7eb',
    marginBottom: 8,
  },
  songItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#020617',
    marginBottom: 8,
    borderWidth: 1,
    borderColor: '#1f2937',
  },
  songTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#f9fafb',
  },
  songArtist: {
    fontSize: 12,
    color: '#9ca3af',
  },
  songActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  secondaryButton: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: '#111827',
    marginRight: 6,
  },
  secondaryButtonText: {
    color: '#e5e7eb',
    fontSize: 12,
  },
  dangerButton: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: '#b91c1c',
  },
  dangerButtonText: {
    color: '#f9fafb',
    fontSize: 12,
  },
  smallButton: {
    backgroundColor: '#22c55e',
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
  },
  smallButtonText: {
    color: '#020617',
    fontSize: 12,
    fontWeight: '600',
  },
  smallOutlineButton: {
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: '#4b5563',
  },
  smallOutlineButtonText: {
    color: '#e5e7eb',
    fontSize: 12,
    fontWeight: '600',
  },
});
