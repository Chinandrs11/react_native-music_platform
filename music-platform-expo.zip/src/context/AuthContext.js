import React, { createContext, useContext, useEffect, useState } from 'react';
import axios from 'axios';
import { Alert } from 'react-native';

const AuthContext = createContext();

// Ajusta esta URL al backend de tu API Node/Express
const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:4000/api';

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadSession = async () => {
      try {
        const savedToken = await globalThis.AsyncStorage?.getItem('token');
        const savedUser = await globalThis.AsyncStorage?.getItem('user');
        if (savedToken && savedUser) {
          setToken(savedToken);
          setUser(JSON.parse(savedUser));
          axios.defaults.headers.common['Authorization'] = `Bearer ${savedToken}`;
        }
      } catch (err) {
        console.log('Error cargando sesión', err);
      } finally {
        setLoading(false);
      }
    };
    loadSession();
  }, []);

  const persistSession = async (tokenValue, userValue) => {
    try {
      if (globalThis.AsyncStorage) {
        await globalThis.AsyncStorage.setItem('token', tokenValue);
        await globalThis.AsyncStorage.setItem('user', JSON.stringify(userValue));
      }
    } catch (err) {
      console.log('Error guardando sesión', err);
    }
  };

  const clearSession = async () => {
    try {
      if (globalThis.AsyncStorage) {
        await globalThis.AsyncStorage.removeItem('token');
        await globalThis.AsyncStorage.removeItem('user');
      }
    } catch (err) {
      console.log('Error limpiando sesión', err);
    }
  };

  const login = async (email, password) => {
    try {
      const { data } = await axios.post(`${API_URL}/auth/login`, { email, password });
      setToken(data.token);
      setUser(data.user);
      axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
      await persistSession(data.token, data.user);
    } catch (error) {
      console.log(error);
      Alert.alert('Error', error.response?.data?.message || 'Error al iniciar sesión');
      throw error;
    }
  };

  const register = async (name, email, password) => {
    try {
      const { data } = await axios.post(`${API_URL}/auth/register`, {
        name,
        email,
        password,
      });
      setToken(data.token);
      setUser(data.user);
      axios.defaults.headers.common['Authorization'] = `Bearer ${data.token}`;
      await persistSession(data.token, data.user);
    } catch (error) {
      console.log(error);
      Alert.alert('Error', error.response?.data?.message || 'Error al registrar');
      throw error;
    }
  };

  const logout = async () => {
    setToken(null);
    setUser(null);
    delete axios.defaults.headers.common['Authorization'];
    await clearSession();
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        login,
        register,
        logout,
        API_URL,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
